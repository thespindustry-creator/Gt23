package com.yourapp;

public class MainActivity {}
