package com.yourapp;

public class SplashActivity {}
